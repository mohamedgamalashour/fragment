public class CustomerState {

    public String state ;
    public int imageId;

    public CustomerState (String state, int imageId){

        this.state = state;
        this.imageId = imageId;

    }


}
